/* 
Faça um programa em C com as seguintes especificações:
a) Crie uma estrutura de nome Endereco com os campos log (logradouro) e num (número).
b) Crie uma estrutura de nome Aluno com os campos nome, nota e end (do tipo Endereco).
c) Crie uma variável do tipo Aluno, leia os dados do aluno e em seguida os imprima.
*/

#include <stdio.h>

struct Endereco {
	char log[100];
	int num;
};

struct Aluno {
	char nome[50];
	float nota;
	struct Endereco end;
};

int main() {
	//Declaração de variáveis
	struct Aluno a; //declaração de variável do tipo estrutura

	//Entrada de dados
	printf("\n=========================================");
	printf("\n*********** Entrada de Dados ************");
	printf("\n=========================================");
	printf("\nNome      : ");
	gets(a.nome);
	printf("Nota      : ");
	scanf("%f",&a.nota);
	getchar(); //limpa o buffer do teclado.
	printf("Logradouro: ");
	gets(a.end.log);
	printf("Número    : ");
	scanf("%d",&a.end.num);
	printf("=========================================\n");

	//Impressão de resultados
	printf("\n=========================================");
	printf("\n******* Impressão de Resultados *********");
	printf("\n=========================================");
	printf("\nNome      : %s",a.nome);
	printf("\nNota      : %.1f",a.nota);
	printf("\nLogradouro: %s",a.end.log);
	printf("\nNúmero    : %d",a.end.num);
	printf("\n=========================================");

	printf("\n\n");

	return 0;
}
