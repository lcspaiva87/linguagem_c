/* 
Faça um programa em C com as seguintes especificações:
a) Crie uma estrutura de nome Endereco com os campos log (logradouro) e num (número).
b) Crie uma estrutura de nome Aluno com os campos nome, nota e end (do tipo Endereco).
c) Crie uma vetor do tipo Aluno, leia os dados dos alunos e em seguida os imprima.
d) Imprima os dados somente dos alunos aprovados (nota >= 6.0).
e) Imprima a maior nota.
f) Imprima os dados dos alunos com nota igual a maior nota.
g) Imprima os dados dos alunos por ordem decrescente de notas.
h) Imprima os dados dos alunos por ordem alfabética.
i) Leia um nome de aluno do teclado e imprima todos os dados do aluno.
j) Leia um logradouro do teclado e imprima os dados de todos os alunos que moram no mesmo logradouro.
k) Leia um valor de nota do teclado e imprima os dados de todos os alunos com nota igual ou superior.
l) Imprima a quantidade de alunos reprovados.
m) Imprima a média aritmética da turma.
*/

#include <stdio.h>
#include <string.h>

struct Endereco {
	char log[100];
	int num;
};

struct Aluno {
	char nome[50];
	float nota;
	struct Endereco end;
};

int main() {
	//Declaração de variáveis
	struct Aluno a[100]; //declaração de vetor do tipo estrutura.
	struct Aluno aux;
	int i,j,n,k, cont;
	float m,maior,nota;
	char nome[50], log[100];

	//Entrada de dados
	printf("\n=========================================");
	printf("\n******* Entrada de Dados: ");
	printf("\n=========================================");
	printf("\nQuantidade de alunos: ");
	scanf("%d",&n);

	for(i=0;i<n;i++) {
		getchar(); //limpa o buffer do teclado.
		printf("\n*** Dados do aluno %d: ",i+1);
		printf("\nNome      : ");
		gets(a[i].nome);
		printf("Nota      : ");
		scanf("%f",&a[i].nota);
		getchar(); //limpa o buffer do teclado.
		printf("Logradouro: ");
		gets(a[i].end.log);
		printf("Número    : ");
		scanf("%d",&a[i].end.num);
	}
	printf("=========================================\n");

	//Impressão dos dados de todos os alunos
	printf("\n=========================================");
	printf("\n******* Dados de todos os alunos: ");
	printf("\n=========================================");
	for(i=0;i<n;i++) {
		printf("\n*** Dados do aluno %d: ",i+1);
		printf("\nNome      : %s",a[i].nome);
		printf("\nNota      : %.1f",a[i].nota);
		printf("\nLogradouro: %s",a[i].end.log);
		printf("\nNúmero    : %d",a[i].end.num);
		printf("\n");
	}
	printf("=========================================\n");

	//Impressão dos dados dos alunos aprovados
	printf("\n=========================================");
	printf("\n******* Dados dos alunos aprovados: ");
	printf("\n=========================================");
	k = 0;
	for(i=0;i<n;i++)
		if(a[i].nota >= 6.0) {
			printf("\n*** Dados do aluno %d: ",i+1);
			printf("\nNome      : %s",a[i].nome);
			printf("\nNota      : %.1f",a[i].nota);
			printf("\nLogradouro: %s",a[i].end.log);
			printf("\nNúmero    : %d",a[i].end.num);
			printf("\n");
			k = 1;
		}
	if(k == 0)
		printf("\n! Nenhum aluno aprovado !\n");
	printf("=========================================\n");

	//Cálculo e impressão da maior nota
	printf("\n=========================================");
	printf("\n******* Maior nota: ");
	maior = a[0].nota;
	for(i=1;i<n;i++)
		if(a[i].nota > maior)
			maior = a[i].nota;
	printf("%.1f",maior);
	printf("\n=========================================\n");

	//Impressão dos dados dos alunos com nota igual a maior nota
	printf("\n=========================================");
	printf("\n******* Dados dos alunos com maior nota: ");
	printf("\n=========================================");
	for(i=0;i<n;i++) {
		if(a[i].nota == maior) {
			printf("\n*** Dados do aluno %d: ",i+1);
			printf("\nNome      : %s",a[i].nome);
			printf("\nNota      : %.1f",a[i].nota);
			printf("\nLogradouro: %s",a[i].end.log);
			printf("\nNúmero    : %d",a[i].end.num);
			printf("\n");
		}
	}
	printf("=========================================\n");

	//Impressão dos dados dos alunos por ordem decrescente de notas
	printf("\n=========================================");
	printf("\n******* Dados dos alunos por ordem decrescente de notas: ");
	printf("\n=========================================");
	for(i=0;i<n-1;i++)
		for(j=i+1;j<n;j++)
			if(a[i].nota < a[j].nota) {
				aux = a[i]; //note que aux é do tipo Aluno
				a[i] = a[j];
				a[j] = aux;
			}
	for(i=0;i<n;i++) {
		printf("\n*** Dados do aluno %d: ",i+1);
		printf("\nNome      : %s",a[i].nome);
		printf("\nNota      : %.1f",a[i].nota);
		printf("\nLogradouro: %s",a[i].end.log);
		printf("\nNúmero    : %d",a[i].end.num);
		printf("\n");
	}
	printf("=========================================\n");

	//Impressão dos dados dos alunos por ordem alfabética
	printf("\n=========================================");
	printf("\n******* Dados dos alunos por ordem alfabética: ");
	printf("\n=========================================");
	for(i=0;i<n-1;i++)
		for(j=i+1;j<n;j++)
			if( strcmp(a[i].nome, a[j].nome) > 0 ) {
				aux = a[i]; //note que aux é do tipo Aluno
				a[i] = a[j];
				a[j] = aux;
			}
	for(i=0;i<n;i++) {
		printf("\n*** Dados do aluno %d: ",i+1);
		printf("\nNome      : %s",a[i].nome);
		printf("\nNota      : %.1f",a[i].nota);
		printf("\nLogradouro: %s",a[i].end.log);
		printf("\nNúmero    : %d",a[i].end.num);
		printf("\n");
	}
	printf("=========================================\n");

	//Busca e impressão dos dados de um aluno pelo nome
	printf("\n=========================================");
	printf("\n******* Busca de dados pelo nome: ");
	printf("\n=========================================");
	getchar(); //limpa buffer do teclado
	printf("\nNome para busca: ");
	gets(nome);
	k = 0;
	for(i=0;i<n;i++)
		if(strcmp(a[i].nome,nome) == 0) {
			printf("\n*** Dados do aluno %d: ",i+1);
			printf("\nNome      : %s",a[i].nome);
			printf("\nNota      : %.1f",a[i].nota);
			printf("\nLogradouro: %s",a[i].end.log);
			printf("\nNúmero    : %d",a[i].end.num);
			printf("\n");
			k = 1;
			break; //termina o laço uma vez que encontrou o aluno
		}
	if(k == 0)
		printf("\n! Aluno não encontrado com o nome: %s !\n",nome);
	printf("=========================================\n");

	//Busca e impressão dos dados dos alunos que moram no mesmo logradouro
	printf("\n=========================================");
	printf("\n******* Busca de dados pelo logradouro: ");
	printf("\n=========================================");
	//getchar(); //limpa buffer do teclado
	printf("\nLogradouro para busca: ");
	gets(log);
	k = 0;
	for(i=0;i<n;i++)
		if(strcmp(a[i].end.log,log) == 0) {
			printf("\n*** Dados do aluno %d: ",i+1);
			printf("\nNome      : %s",a[i].nome);
			printf("\nNota      : %.1f",a[i].nota);
			printf("\nLogradouro: %s",a[i].end.log);
			printf("\nNúmero    : %d",a[i].end.num);
			printf("\n");
			k = 1;
		}
	if(k == 0)
		printf("\n! Logradouro não encontrado com o nome: %s !\n",log);
	printf("=========================================\n");

	//Impressão dos dados dos aluno com nota igual ou superior a uma nota lida do teclado
	printf("\n=========================================");
	printf("\n******* Dados dos alunos com notas iguais ou superiores: ");
	printf("\n=========================================");
	printf("\nNota para busca: ");
	scanf("%f",&nota);
	k = 0;
	for(i=0;i<n;i++)
		if(a[i].nota >= nota) {
			printf("\n*** Dados do aluno %d: ",i+1);
			printf("\nNome      : %s",a[i].nome);
			printf("\nNota      : %.1f",a[i].nota);
			printf("\nLogradouro: %s",a[i].end.log);
			printf("\nNúmero    : %d",a[i].end.num);
			printf("\n");
			k = 1;
		}
	if(k == 0)
		printf("\n! Nota não encontrada com valor igual ou superior a: %.1f !\n",nota);
	printf("=========================================\n");

	//Quantidade de alunos reprovados
	printf("\n=========================================");
	printf("\n******* Quant. de alunos reprovados: ");
	cont = 0;
	for(i=0;i<n;i++)
		if(a[i].nota < 6.0)
			cont++;
	printf("%d",cont);
	printf("\n=========================================\n");

	//Média aritmética da turma
	printf("\n=========================================");
	printf("\n******* Média aritmética da turma: ");
	m = 0.0;
	for(i=0;i<n;i++)
		m = m + a[i].nota;
	m = m/n;
	printf("%.1f",m);
	printf("\n=========================================\n");

	printf("\n\n");

	return 0;
}
