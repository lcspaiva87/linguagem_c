/* 
Faça um programa em C com as seguintes especificações:
a) Crie uma estrutura de nome Endereco com os campos log (logradouro) e num (número).
b) Crie uma estrutura de nome Aluno com os campos nome, nota e end (do tipo Endereco).
c) Crie um ponteiro do tipo Aluno, aloque memória dinamicamente para o ponteiro, leia os dados dos alunos e em seguida os imprima.
d) Imprima os dados somente dos alunos aprovados (nota >= 6.0). Faça uma função com protótipo: void imprimeDados(struct Aluno *p, int n, float nota). A função deve imprimir os dados de todos que tenham nota maior ou igual ao argumento nota.
e) Imprima a maior nota. Faça uma função com protótipo: float maiorNota(struct Aluno *p, int n).
f) Imprima os dados dos alunos com nota igual a maior nota. Utilize a função do item d.
g) Imprima os dados dos alunos por ordem decrescente de notas. Faça uma função com protótipo: void ordenaDecrescentePorNota(struct Aluno *p, int n). A impressão deve ser feita pelo main.
h) Imprima os dados dos alunos por ordem alfabética. Faça uma função com protótipo: void ordemAlfabetica(struct Aluno *p, int n). A impressão deve ser feita pelo main.
i) Leia um nome de aluno do teclado e imprima todos os dados do aluno. Faça uma função com protótipo: void buscaPorNome(struct Aluno *p, int n, char *nome). A função deve imprir os dados.
j) Leia um logradouro do teclado e imprima os dados de todos os alunos que moram no mesmo logradouro. Faça uma função com protótipo: void buscaPorLogradouro(struct Aluno *p, int n, char *log). A função deve imprir os dados.
k) Leia um valor de nota do teclado e imprima os dados de todos os alunos com nota igual ou superior. Utilize a função do item d.
l) Imprima a média aritmética da turma. Faça uma função com protótipo: float mediaTurma(struct Aluno *p, int n). A função retorna a média aritmética da turma.

OBSERVAÇÃO: FAÇA FUNÇÕES 
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct Endereco {
	char log[100];
	int num;
};

struct Aluno {
	char nome[50];
	float nota;
	struct Endereco end;
};

void imprimeDados(struct Aluno *p, int n, float nota);
float maiorNota(struct Aluno *p, int n);
void ordenaDecrescentePorNota(struct Aluno *p, int n);
void ordemAlfabetica(struct Aluno *p, int n);
void buscaPorNome(struct Aluno *p, int n, char *nome);
void buscaPorLogradouro(struct Aluno *p, int n, char *log);
float mediaTurma(struct Aluno *p, int n);

int main() {
	//Declaração de variáveis
	struct Aluno *a; //declaração de ponteiro do tipo estrutura.
	int i,j,n;
	float m,maior,nota;
	char nome[50], log[100];

	//Entrada de dados
	printf("\n=========================================");
	printf("\n******* Entrada de Dados: ");
	printf("\n=========================================");
	printf("\nQuantidade de alunos: ");
	scanf("%d",&n);

	//Alocação dinâmica de memória
	a = (struct Aluno *) malloc(n*sizeof(struct Aluno));
	if(a == NULL) {
		printf("\nERRO - Memória insuficiente");
		exit(1);
	}

	for(i=0;i<n;i++) {
		getchar(); //limpa o buffer do teclado.
		printf("\n*** Dados do aluno %d: ",i+1);
		printf("\nNome      : ");
		gets(a[i].nome);
		printf("Nota      : ");
		scanf("%f",&a[i].nota);
		getchar(); //limpa o buffer do teclado.
		printf("Logradouro: ");
		gets(a[i].end.log);
		printf("Número    : ");
		scanf("%d",&a[i].end.num);
	}
	printf("=========================================\n");

	//Impressão dos dados de todos os alunos
	printf("\n=========================================");
	printf("\n******* Dados de todos os alunos: ");
	printf("\n=========================================");
	for(i=0;i<n;i++) {
		printf("\n*** Dados do aluno %d: ",i+1);
		printf("\nNome      : %s",a[i].nome);
		printf("\nNota      : %.1f",a[i].nota);
		printf("\nLogradouro: %s",a[i].end.log);
		printf("\nNúmero    : %d",a[i].end.num);
		printf("\n");
	}
	printf("=========================================\n");

	//Impressão dos dados dos alunos aprovados
	printf("\n=========================================");
	printf("\n******* Dados dos alunos aprovados: ");
	printf("\n=========================================");
	imprimeDados(a,n,6.0);
	printf("=========================================\n");

	//Cálculo e impressão da maior nota
	printf("\n=========================================");
	printf("\n******* Maior nota: ");
	maior = maiorNota(a,n);
	printf("%.1f",maior);
	printf("\n=========================================\n");

	//Impressão dos dados dos alunos com nota igual a maior nota
	printf("\n=========================================");
	printf("\n******* Dados dos alunos com maior nota: ");
	printf("\n=========================================");
	imprimeDados(a,n,maior);
	printf("=========================================\n");

	//Impressão dos dados dos alunos por ordem decrescente de notas
	printf("\n=========================================");
	printf("\n******* Dados dos alunos por ordem decrescente de notas: ");
	printf("\n=========================================");
	ordenaDecrescentePorNota(a,n);
	for(i=0;i<n;i++) {
		printf("\n*** Dados do aluno %d: ",i+1);
		printf("\nNome      : %s",a[i].nome);
		printf("\nNota      : %.1f",a[i].nota);
		printf("\nLogradouro: %s",a[i].end.log);
		printf("\nNúmero    : %d",a[i].end.num);
		printf("\n");
	}
	printf("=========================================\n");

	//Impressão dos dados dos alunos por ordem alfabética
	printf("\n=========================================");
	printf("\n******* Dados dos alunos por ordem alfabética: ");
	printf("\n=========================================");
	ordemAlfabetica(a,n);
	for(i=0;i<n;i++) {
		printf("\n*** Dados do aluno %d: ",i+1);
		printf("\nNome      : %s",a[i].nome);
		printf("\nNota      : %.1f",a[i].nota);
		printf("\nLogradouro: %s",a[i].end.log);
		printf("\nNúmero    : %d",a[i].end.num);
		printf("\n");
	}
	printf("=========================================\n");

	//Busca e impressão dos dados de um aluno pelo nome
	printf("\n=========================================");
	printf("\n******* Busca de dados pelo nome: ");
	printf("\n=========================================");
	getchar(); //limpa buffer do teclado
	printf("\nNome para busca: ");
	gets(nome);
	buscaPorNome(a,n,nome);
	printf("=========================================\n");

	//Busca e impressão dos dados dos alunos que moram no mesmo logradouro
	printf("\n=========================================");
	printf("\n******* Busca de dados pelo logradouro: ");
	printf("\n=========================================");
	//getchar(); //limpa buffer do teclado
	printf("\nLogradouro para busca: ");
	gets(log);
	buscaPorLogradouro(a,n,log);
	printf("=========================================\n");

	//Impressão dos dados dos aluno com nota igual ou superior a uma nota lida do teclado
	printf("\n=========================================");
	printf("\n******* Dados dos alunos com notas iguais ou superiores: ");
	printf("\n=========================================");
	printf("\nNota para busca: ");
	scanf("%f",&nota);
	imprimeDados(a,n,nota);
	printf("=========================================\n");

	//Média aritmética da turma
	printf("\n=========================================");
	printf("\n******* Média aritmética da turma: ");
	m = mediaTurma(a,n);
	printf("%.1f",m);
	printf("\n=========================================\n");

	//Libera memória alocada para o ponteiro
	free(a);

	printf("\n\n");

	return 0;
}


void imprimeDados(struct Aluno *p, int n, float nota) {
	int i,k;
	k = 0;
	for(i=0;i<n;i++)
		if(p[i].nota >= nota) {
			printf("\n*** Dados do aluno %d: ",i+1);
			printf("\nNome      : %s",p[i].nome);
			printf("\nNota      : %.1f",p[i].nota);
			printf("\nLogradouro: %s",p[i].end.log);
			printf("\nNúmero    : %d",p[i].end.num);
			printf("\n");
			k = 1;
		}
	if(k == 0)
		printf("\n! Nenhum aluno com nota maior ou igual a: %.1f !\n",nota);		
}

float maiorNota(struct Aluno *p, int n) {
	int i;
	float maior;
	maior = p[0].nota;
	for(i=1;i<n;i++)
		if(p[i].nota > maior)
			maior = p[i].nota;
	return maior;
}

void ordenaDecrescentePorNota(struct Aluno *p, int n) {
	int i,j;
	struct Aluno aux;
	for(i=0;i<n-1;i++)
		for(j=i+1;j<n;j++)
			if(p[i].nota < p[j].nota) {
				aux = p[i]; //note que aux é do tipo Aluno
				p[i] = p[j];
				p[j] = aux;
			}
}

void ordemAlfabetica(struct Aluno *p, int n) {
	int i,j;
	struct Aluno aux;
	for(i=0;i<n-1;i++)
		for(j=i+1;j<n;j++)
			if( strcmp(p[i].nome, p[j].nome) > 0 ) {
				aux = p[i]; //note que aux é do tipo Aluno
				p[i] = p[j];
				p[j] = aux;
			}
}

void buscaPorNome(struct Aluno *p, int n, char *nome) {
	int i,k;
	k = 0;
	for(i=0;i<n;i++)
		if(strcmp(p[i].nome,nome) == 0) {
			printf("\n*** Dados do aluno %d: ",i+1);
			printf("\nNome      : %s",p[i].nome);
			printf("\nNota      : %.1f",p[i].nota);
			printf("\nLogradouro: %s",p[i].end.log);
			printf("\nNúmero    : %d",p[i].end.num);
			printf("\n");
			k = 1;
			break; //termina o laço uma vez que encontrou o aluno
		}
	if(k == 0)
		printf("\n! Aluno não encontrado com o nome: %s !\n",nome);
}

void buscaPorLogradouro(struct Aluno *p, int n, char *log) {
	int i,k;
	k = 0;
	for(i=0;i<n;i++)
		if(strcmp(p[i].end.log,log) == 0) {
			printf("\n*** Dados do aluno %d: ",i+1);
			printf("\nNome      : %s",p[i].nome);
			printf("\nNota      : %.1f",p[i].nota);
			printf("\nLogradouro: %s",p[i].end.log);
			printf("\nNúmero    : %d",p[i].end.num);
			printf("\n");
			k = 1;
		}
	if(k == 0)
		printf("\n! Logradouro não encontrado com o nome: %s !\n",log);
}

float mediaTurma(struct Aluno *p, int n) {
	int i;
	float m;
	m = 0.0;
	for(i=0;i<n;i++)
		m = m + p[i].nota;
	m = m/n;
	return m;
}
